<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Place extends Model
{
    use HasFactory;
    public $incrementing = false;
    protected $fillable = [
        'id',
        'name',
        'imageUrl',
        'name',
        'categoryId',
        'cityId',
        'address',
        'phoneNumber',
        'searchedTimes',
        'postedBy',
    ];
}
